/** Text-normalization language. `'none'` hands text to the tokenizer as written. */
export type Lang =
  | 'en' | 'fr' | 'de' | 'es' | 'pt' | 'ar' | 'hi' | 'ko' | 'pl' | 'sv' | 'fi' | 'no' | 'it' | 'nl'
  | 'ja' | 'zh' | 'da' | 'tr' | 'none';

/** Weight format. `q8` is smaller and faster on CPU. */
export type Quant = 'f32' | 'q8';

/** Where a checkpoint's files are. Relative URLs resolve against the page. */
export interface ModelSpec {
  /** Weights file per format: safetensors or GGUF. Only the `quant` being loaded is needed. */
  weights: Partial<Record<Quant, string | URL>>;
  /** The checkpoint's `tokenizer.json`. */
  tokenizer: string | URL;
  /** Required URL of this checkpoint's `config.json`. */
  config: string | URL;
  /**
   * Voice name to voice `.safetensors` file. Fetched on first use. A model without any can
   * still be loaded, but every request then needs a voice added with `addVoice` first.
   */
  voices?: Record<string, string | URL>;
  /** Voice used when a request names none. Defaults to the first of `voices`. */
  defaultVoice?: string;
}

export interface LoadProgress {
  /** `'weights'`, `'tokenizer'`, `'config'` or `'voice:<name>'`. */
  file: string;
  loaded: number;
  /** `null` when the server did not say. */
  total: number | null;
  /** The file came from the browser cache rather than the network. */
  cached: boolean;
}

export interface LoadOptions {
  /**
   * Required. The language text is normalized as before it is tokenized: numbers, dates and
   * symbols are read out the way a speaker of that language would, which the model reads
   * noticeably better. The spoken forms differ per language, so there is no default.
   */
  lang: Lang;
  /**
   * Which word rewrites run on the normalized text: `'default'` (the default: numbers,
   * currency, dashed-digits, emails, urls, abbreviations, elongations), `'all'` (those and phones, times, dates), `'none'`
   * (or `'off'`), or a comma-separated list of rule names. Case and surrounding space do not
   * matter, and `'default'` / `'all'` / `'none'` / `'off'` count only on their own, not inside a
   * list. Ignored when `lang` is `'none'`, which does
   * not normalize at all, and the rules only read `'en'`, `'fr'`, `'de'`, `'es'` and `'pt'`.
   */
  rewrites?: string;
  /**
   * Values for the conditioners the checkpoint's `config.json` lists, by name, e.g.
   * `{ duration_delta: 0.5 }`. Those left out take their defaults. A name the checkpoint does not
   * have is an error once its config is loaded.
   */
  conditions?: Record<string, string | number>;
  /** Default `'q8'`. */
  quant?: Quant;
  /**
   * Where the checkpoint's files are, or a public Hugging Face repo as `'hf://owner/name'` or
   * `'hf://owner/name@revision'`, whose files are picked as the native frontends pick them.
   * Default: {@link DEFAULT_MODEL}.
   */
  model?: ModelSpec | string;
  /** Voices to fetch up front. Default: just the default voice; others load on first use. */
  voices?: string[];
  /** Keep downloads in the Cache API, so the model is fetched once per browser. Default `true`. */
  cache?: boolean;
  onProgress?: (progress: LoadProgress) => void;
  /** Where `worker.js` is, for a bundler that does not pick it up from `new URL(..., import.meta.url)`. */
  workerUrl?: string | URL;
  /** Where `phonon_tts_bg.wasm` is, when it is served from somewhere other than beside the worker. */
  wasmUrl?: string | URL;
  /** The same for the threaded build, `wasm-threads/phonon_tts_bg.wasm`. */
  threadsWasmUrl?: string | URL;
  /**
   * The same for the modules browsers without WebAssembly Relaxed SIMD load, such as Safari:
   * `wasm/phonon_tts_simd_bg.wasm` and `wasm-threads/phonon_tts_simd_bg.wasm`.
   */
  simdWasmUrl?: string | URL;
  threadsSimdWasmUrl?: string | URL;
  /**
   * CPU threads to generate on, counting the worker that owns the model. Default `'auto'`:
   * 3, or fewer if the device has fewer cores. Threads
   * need a cross-origin isolated page (see the README); elsewhere generation runs on one
   * thread whatever this says, and {@link PhononTTS.threadsReason} says why.
   */
  threads?: number | 'auto';
  /**
   * Where to generate. Default `'cpu'`. WebGPU is opt in, since it is not faster than the CPU
   * on every device. `'webgpu'` insists on the GPU and rejects if it cannot start. `'auto'`
   * uses the GPU when the browser has a hardware WebGPU adapter and `quant` is `'q8'`, and
   * the CPU otherwise or if WebGPU fails to start. {@link PhononTTS.deviceReason} says why
   * the model ended up where it did.
   */
  device?: 'auto' | 'webgpu' | 'cpu';
}

export interface SpeechOptions {
  /** A name from {@link PhononTTS.voices}. Default: the model's default voice. */
  voice?: string;
  /** Sampling temperature. Default `0.3`. */
  temperature?: number;
  /**
   * Noise seed: the same text, voice, temperature and seed give the same audio. On the CPU that
   * is the audio the Rust and Python packages give too; on WebGPU the GPU draws its own noise,
   * so the audio differs from the CPU's. Default `4242424242424242`, as there. Above
   * `Number.MAX_SAFE_INTEGER`, pass a `bigint`.
   */
  seed?: number | bigint;
  /** Aborting stops generation and discards unread chunks. Stop scheduled playback separately. */
  signal?: AbortSignal;
}

export interface SpeechStats {
  /** Sentence-aligned chunks the text was split into. */
  chunks?: number;
  tokens?: number;
  /** 80 ms frames generated. */
  frames?: number;
  samples?: number;
  /**
   * Time spent prompting the model with each chunk's text, summed. On WebGPU the prompt runs
   * on the GPU with the chunk's first frames, so this reads zero there.
   */
  promptMs?: number;
  /**
   * Generation time per frame: each step's time divided by its frames. A step is one frame on
   * the CPU; on WebGPU it is a piece of audio as it arrives, 1, 2, 4 or 8 frames, so there
   * `min` and `max` are averages over a piece, and each chunk's first piece also covers its
   * prompt.
   */
  stepMs?: { avg: number; min: number; max: number };
  /** From the request starting in the worker to its first audio. */
  firstAudioMs?: number | null;
  totalMs?: number;
  /** The generation was stopped before it finished. */
  cancelled: boolean;
}

/** Audio as it is generated. Iterate it once. */
export interface SpeechStream extends AsyncIterable<Float32Array> {
  readonly sampleRate: number;
  /** Resolves with timing stats once generation ends, or rejects if it failed. */
  readonly done: Promise<SpeechStats>;
  /** Stop generating and discard unread chunks. Await `done` for cleanup. Breaking out of a `for await` loop does the same. */
  cancel(): void;
}

export declare class PhononTTS {
  /** Download (or read from cache) a checkpoint and start it in a worker. */
  static load(options: LoadOptions): Promise<PhononTTS>;
  private constructor();

  /** Samples per second of the audio this model produces (24000 for Phonon). */
  readonly sampleRate: number;
  /** SIMD features the wasm module was built with, e.g. `{ simd128: true }`. */
  readonly features: Record<string, boolean>;
  /** Where generation runs. */
  readonly device: 'webgpu' | 'cpu';
  /** Why {@link PhononTTS.device} is what it is, e.g. `'this browser offers no WebGPU adapter'`. */
  readonly deviceReason: string;
  /** CPU threads generation runs on, counting the worker that owns the model. 1 on WebGPU. */
  readonly threads: number;
  /** Why {@link PhononTTS.threads} is what it is, e.g. `'the page is not cross-origin isolated'`. */
  readonly threadsReason: string;
  /** Voices this model can speak with: bundled ones and any added. */
  readonly voices: string[];
  /** The languages the model was trained for, as listed in its config. */
  readonly languages: string[];

  /**
   * Register a voice from a voice `.safetensors` file: a precomputed embedding (`emb`) or
   * the KV-cache format of `embeddings_v2/`.
   */
  addVoice(name: string, source: string | URL | ArrayBuffer | Uint8Array | Blob): Promise<void>;
  /**
   * Speak `text`, yielding mono PCM at `sampleRate` as it is generated, 80 ms per chunk.
   * Long text is split at sentence boundaries. Requests run one at a time, in order.
   */
  stream(text: string, options?: SpeechOptions): SpeechStream;
  /** Speak `text` and return the whole waveform. */
  synth(text: string, options?: SpeechOptions): Promise<Float32Array>;
  /** Speak `text` and return a 16-bit mono WAV file. */
  synthWav(text: string, options?: SpeechOptions): Promise<Blob>;
  /** Stop the worker and free the model. Pending requests fail. */
  dispose(): void;
}

/** Delete every file this package has cached. Resolves to whether there was anything. */
export declare function clearCache(): Promise<boolean>;

/** The model `PhononTTS.load` uses when none is given, as `hf://owner/name@revision`. */
export declare const DEFAULT_MODEL: string;

/** Encode mono float PCM as a 16-bit WAV file. */
export declare function encodeWav(pcm: Float32Array, sampleRate: number): Blob;

/** Join PCM chunks into one buffer. */
export declare function concatPcm(chunks: Float32Array[]): Float32Array;
