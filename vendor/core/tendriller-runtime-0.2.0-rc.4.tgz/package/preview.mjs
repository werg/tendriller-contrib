// runtime/src/preview.ts
function createFixtureTransport() {
  const sockets = /* @__PURE__ */ new Set();
  const listeners = /* @__PURE__ */ new Set();
  const receive = (frame) => {
    for (const socket of sockets) if (socket.readyState === 1) socket.onmessage?.({ data: JSON.stringify(frame) });
  };
  return {
    socket() {
      const socket = {
        readyState: 0,
        onopen: null,
        onmessage: null,
        onerror: null,
        onclose: null,
        send(data) {
          if (socket.readyState !== 1) throw new Error("Fixture socket is closed");
          const frame = JSON.parse(data);
          const reply = (message) => queueMicrotask(() => {
            if (socket.readyState === 1) socket.onmessage?.({ data: JSON.stringify(message) });
          });
          for (const listener of listeners) listener(frame, reply);
        },
        close() {
          if (socket.readyState === 3) return;
          socket.readyState = 3;
          sockets.delete(socket);
          socket.onclose?.();
        }
      };
      sockets.add(socket);
      queueMicrotask(() => {
        if (socket.readyState === 0) {
          socket.readyState = 1;
          socket.onopen?.();
        }
      });
      return socket;
    },
    receive,
    emit(event, data) {
      receive({ t: "fixture_event", event, data });
    },
    onSend(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    disconnect() {
      for (const socket of [...sockets]) socket.close();
    }
  };
}
export {
  createFixtureTransport
};
