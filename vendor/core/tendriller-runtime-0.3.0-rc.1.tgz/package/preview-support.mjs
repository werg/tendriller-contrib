// contract/durability.mjs
var integer = { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER };
var nullableInteger = { anyOf: [integer, { type: "null" }] };
var object = (properties, required = [], additionalProperties = false) => ({ type: "object", properties, required, additionalProperties });
var consumerName = { type: "string", pattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$" };
var consumerLeaseToken = { type: "string", pattern: "^cl_[a-z2-7]{40}$" };
var ttl = { type: "integer", minimum: 30, maximum: 900 };
var consumer = object({
  name: consumerName,
  handled_seq: integer,
  delivered_seq: integer,
  generation: integer,
  lease: { anyOf: [object({ holder: { type: "string", minLength: 1, maxLength: 100 }, expires_at: integer }, ["holder", "expires_at"]), { type: "null" }] },
  created_at: integer,
  updated_at: integer
}, ["name", "handled_seq", "delivered_seq", "generation", "lease", "created_at", "updated_at"]);
var history = object({ earliest_available_seq: nullableInteger, latest_seq: integer, gap: { type: "boolean" }, missing_through: nullableInteger }, ["earliest_available_seq", "latest_seq", "gap", "missing_through"]);
var durabilitySchemas = {
  consumerName,
  consumerLeaseToken,
  consumer,
  consumerList: object({ consumers: { type: "array", items: consumer } }, ["consumers"]),
  consumerResult: object({ consumer }, ["consumer"]),
  consumerClaim: object({ holder: { type: "string", minLength: 1, maxLength: 100 }, ttl_seconds: ttl, after: integer }, ["holder"]),
  consumerLease: object({ consumer, lease_token: consumerLeaseToken }, ["consumer", "lease_token"]),
  consumerRenew: object({ ttl_seconds: ttl }),
  consumerAck: object({ through: integer, gap_acknowledged: { type: "boolean" } }, ["through"]),
  consumerBatch: object({ consumer, events: { type: "array", maxItems: 500, items: { $ref: "#/$defs/event" } }, cursor: integer, history }, ["consumer", "events", "cursor", "history"]),
  timerDelivery: object({
    state: { enum: ["pending", "sending", "sent", "failed", "cancelled", "unavailable"] },
    attempts: { type: "integer", minimum: 0, maximum: 6 },
    next_attempt_at: nullableInteger,
    last_attempt_at: nullableInteger,
    last_error: { type: ["string", "null"] },
    sent: integer,
    failed: integer
  }, ["state", "attempts", "next_attempt_at", "last_attempt_at", "last_error", "sent", "failed"])
};

// contract/limits.mjs
var RESOURCE_LIMITS = Object.freeze({
  file_bytes: 25 * 1024 * 1024,
  blob_bytes: 25 * 1024 * 1024,
  event_bytes: 64 * 1024,
  state_bytes: 1024 * 1024,
  files_per_publication: 2e3,
  path_characters: 512,
  active_scopes: 128,
  scope_bindings: 4096,
  command_receipts: 2e4,
  command_receipt_bytes: 32 * 1024 * 1024,
  // Hard transport ceiling is separate from the actor's effective per-body quota.
  owned_body_bytes: 5 * 1024 * 1024,
  unclaimed_body_bytes: 1 * 1024 * 1024,
  owned_page_bytes: 25 * 1024 * 1024,
  unclaimed_page_bytes: 2 * 1024 * 1024,
  upload_sessions_per_actor: 8,
  upload_sessions_per_page: 32,
  upload_expiry_seconds: 86400,
  shared_files: 512,
  shared_file_paths: 4096,
  file_snapshot_bytes: 1024 * 1024,
  file_history: 10,
  file_history_seconds: 30 * 86400
});
var STREAM_LIMITS = Object.freeze({
  streams: 64,
  producers: 32,
  subscriptions: 16,
  record_bytes: 64 * 1024,
  snapshot_record_bytes: 192 * 1024,
  batch_bytes: 256 * 1024,
  replay_bytes: 512 * 1024,
  retained_bytes: 8 * 1024 * 1024,
  unclaimed_retained_bytes: 1024 * 1024,
  retained_records: 2e4,
  stream_records: 1e4,
  retention_seconds: 30 * 86400,
  batch_records: 100,
  replay_records: 500
});

// contract/streams.mjs
var STREAM_RECORD_BYTES = STREAM_LIMITS.record_bytes;
var STREAM_SNAPSHOT_RECORD_BYTES = STREAM_LIMITS.snapshot_record_bytes;
var integer2 = { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER };
var nullableInteger2 = { anyOf: [integer2, { type: "null" }] };
var object2 = (properties, required = [], additionalProperties = false) => ({ type: "object", properties, required, additionalProperties });
var name = { type: "string", pattern: "^[a-z][a-z0-9._-]{0,63}$" };
var customName = { type: "string", pattern: "^(?!system\\.)[a-z][a-z0-9._-]{0,63}$" };
var durability = { enum: ["durable", "ephemeral"] };
var json = { $ref: "#/$defs/streamJson" };
var jsonValue = { anyOf: [
  { type: "null" },
  { type: "boolean" },
  { type: "number" },
  { type: "string" },
  { type: "array", items: json },
  { type: "object", additionalProperties: json }
] };
var input = object2({
  id: { type: "string", minLength: 1, maxLength: 128 },
  ts: integer2,
  type: { type: "string", minLength: 1, maxLength: 80 },
  data: json
}, ["id", "type", "data"]);
var record = object2({
  stream: name,
  seq: integer2,
  ts: { type: "number" },
  received_at: { type: "number" },
  type: { type: "string", minLength: 1, maxLength: 80 },
  data: json,
  producer: { type: "string", minLength: 1, maxLength: 200 },
  id: { anyOf: [input.properties.id, { type: "null" }] }
}, ["stream", "seq", "ts", "received_at", "type", "data", "producer", "id"]);
var history2 = object2({
  earliest_available_seq: nullableInteger2,
  latest_seq: integer2,
  gap: { type: "boolean" },
  missing_through: nullableInteger2
}, ["earliest_available_seq", "latest_seq", "gap", "missing_through"]);
var info = object2({
  name,
  durability,
  readers: { enum: ["agent", "owner", "page"] },
  builtin: { type: "boolean" },
  max_records: nullableInteger2,
  max_age_seconds: nullableInteger2
}, ["name", "durability", "readers", "builtin", "max_records", "max_age_seconds"]);
var batch = object2({
  stream: name,
  durability,
  records: { type: "array", maxItems: STREAM_LIMITS.replay_records, items: record },
  cursor: integer2,
  history: history2
}, ["stream", "durability", "records", "cursor", "history"]);
var producer = object2({
  name,
  streams: { type: "array", minItems: 1, maxItems: 32, items: customName },
  created_at: integer2,
  last_seen: nullableInteger2
}, ["name", "streams", "created_at", "last_seen"]);
var streamSchemas = {
  streamName: name,
  streamCustomName: customName,
  streamJson: jsonValue,
  streamInfo: info,
  streamCreate: { anyOf: [
    object2({
      name: customName,
      durability: { const: "durable" },
      readers: { enum: ["owner", "page"] },
      max_records: { type: "integer", minimum: 1, maximum: STREAM_LIMITS.stream_records },
      max_age_seconds: { type: "integer", minimum: 1, maximum: STREAM_LIMITS.retention_seconds }
    }, ["name", "durability"]),
    object2({ name: customName, durability: { const: "ephemeral" }, readers: { enum: ["owner", "page"] } }, ["name", "durability"])
  ] },
  streamInput: input,
  streamRecord: record,
  streamHistory: history2,
  streamAppend: object2({ records: { type: "array", minItems: 1, maxItems: STREAM_LIMITS.batch_records, items: input } }, ["records"]),
  streamAppendResult: object2({ records: { type: "array", maxItems: STREAM_LIMITS.batch_records, items: record }, cursor: integer2, durability }, ["records", "cursor", "durability"]),
  streamBatch: batch,
  streamLatest: object2({
    stream: name,
    durability: { const: "durable" },
    record: { anyOf: [record, { type: "null" }] },
    cursor: integer2
  }, ["stream", "durability", "record", "cursor"]),
  streamTrim: object2({ through: integer2 }, ["through"]),
  streamTrimResult: object2(
    { stream: name, through: integer2, deleted_records: integer2, cursor: integer2 },
    ["stream", "through", "deleted_records", "cursor"]
  ),
  streamList: object2({ streams: { type: "array", items: info } }, ["streams"]),
  streamSubscription: object2({ stream: name, durability, cursor: integer2, batch }, ["stream", "durability", "cursor"], true),
  producer,
  producerCreate: object2({ name, streams: producer.properties.streams }, ["name", "streams"]),
  producerList: object2({ producers: { type: "array", items: producer } }, ["producers"]),
  producerResult: object2({ producer, token: { type: "string", pattern: "^tp_[a-z2-7]{32,64}$" } }, ["producer", "token"])
};

// contract/blobs.mjs
var s = (maxLength = 200) => ({ type: "string", minLength: 1, maxLength });
var n = { type: "integer", minimum: 0 };
var bool = { type: "boolean" };
var obj = (properties, required = []) => ({ type: "object", properties, required, additionalProperties: false });
var arr = (items, maxItems) => ({ type: "array", items, ...maxItems === void 0 ? {} : { maxItems } });
var blobIdSchema = { type: "string", pattern: "^b_[a-z2-7]{20}$" };
var sha256Schema = { type: "string", pattern: "^[a-f0-9]{64}$" };
var uploadIdSchema = { type: "string", pattern: "^u_[a-z2-7]{20}$" };
var cid = { type: "string", pattern: "^[A-Za-z0-9_.:-]{1,200}$" };
var scope = { type: "string", pattern: "^[A-Za-z0-9_.:-]{1,160}$" };
var expected = { type: "object", maxProperties: 128, propertyNames: scope, additionalProperties: s(160) };
var guards = { cid, expected_generations: expected, scope };
var requiredGuards = ["cid", "expected_generations"];
var filePathSchema = {
  type: "string",
  minLength: 1,
  maxLength: RESOURCE_LIMITS.path_characters,
  "x-canonical-nfc": true,
  pattern: "^(?!/)(?!.*\\/$)(?!(?:_tendril|_publications)(?:/|$))(?!.*(?:^|/)\\.{1,2}(?:/|$))(?!.*//)[^\\\\\\x00-\\x1f\\x7f]+$"
};
var metadata = {
  id: blobIdSchema,
  sha256: sha256Schema,
  size: { type: "integer", minimum: 0, maximum: RESOURCE_LIMITS.blob_bytes },
  type: s(),
  name: { type: "string", maxLength: 200 },
  url: s(2048),
  created_at: n,
  retention: obj({ expires_at: { type: ["integer", "null"], minimum: 0 }, reasons: arr(s(), 32) })
};
var blob = obj(metadata, ["id", "sha256", "size", "type"]);
var attachment = obj({ blob_id: blobIdSchema, name: { type: "string", maxLength: 200 } }, ["blob_id"]);
var file = obj({
  path: filePathSchema,
  revision: { type: "integer", minimum: 1 },
  blob_id: { anyOf: [blobIdSchema, { type: "null" }] },
  name: { type: "string", maxLength: 200 },
  type: s(),
  scope: { anyOf: [scope, { type: "null" }] },
  updated_at: n,
  by: s()
}, ["path", "revision", "blob_id"]);
var publicationFile = obj({ path: filePathSchema, blob_id: blobIdSchema, type: s() }, ["path", "blob_id", "type"]);
var transferError = obj({ code: s(), message: s(1e3), retryable: bool, details: { type: "object" } }, ["code", "message"]);
var blobSchemas = Object.freeze({
  blobId: blobIdSchema,
  blobSha256: sha256Schema,
  filePath: filePathSchema,
  blobMetadata: blob,
  blobList: obj({ blobs: arr(blob, 1e3), cursor: { type: ["string", "null"] } }, ["blobs"]),
  blobAttachment: attachment,
  blobAttachments: arr(attachment, 16),
  uploadStart: obj({ cid, sha256: sha256Schema, size: metadata.size, type: s(), name: { type: "string", maxLength: 200 } }, ["cid", "sha256", "size", "type"]),
  uploadSession: obj({
    id: uploadIdSchema,
    blob_id: blobIdSchema,
    sha256: sha256Schema,
    size: metadata.size,
    phase: { enum: ["reserved", "ready", "receiving", "received", "completed", "aborted", "expired"] },
    upload_required: bool,
    expires_at: n,
    blob
  }, ["id", "blob_id", "sha256", "size", "phase", "upload_required", "expires_at"]),
  uploadCompletion: obj({ status: { const: "completed" }, blob }, ["status", "blob"]),
  blobPin: obj({ ...guards, keep: bool }, [...requiredGuards, "keep"]),
  fileHead: file,
  fileSnapshot: obj({ files: arr(file, RESOURCE_LIMITS.shared_files), cursor: n }, ["files", "cursor"]),
  fileHistory: obj({ path: filePathSchema, versions: arr(file, RESOURCE_LIMITS.file_history + 1) }, ["path", "versions"]),
  fileWrite: obj({
    ...guards,
    path: filePathSchema,
    expected_revision: n,
    blob_id: blobIdSchema,
    name: { type: "string", maxLength: 200 },
    type: s()
  }, [...requiredGuards, "path", "expected_revision", "blob_id"]),
  fileDelete: obj({ ...guards, path: filePathSchema, expected_revision: n }, [...requiredGuards, "path", "expected_revision"]),
  fileCleanup: obj(
    { ...guards, path: filePathSchema, expected_revision: { type: "integer", minimum: 1 } },
    [...requiredGuards, "path", "expected_revision"]
  ),
  fileResult: obj({ file, cursor: n }, ["file", "cursor"]),
  fileChange: obj({ cursor: n, file, cid, actor: s(), at: n }, ["cursor", "file", "cid", "actor", "at"]),
  publicationFile,
  publicationWrite: obj({
    ...guards,
    expected_head_revision: n,
    entry: filePathSchema,
    files: arr(publicationFile, RESOURCE_LIMITS.files_per_publication),
    message: { type: "string", maxLength: 2e3 }
  }, [...requiredGuards, "expected_head_revision", "entry", "files"]),
  publicationRollback: obj(
    { ...guards, expected_head_revision: n, version: { type: "integer", minimum: 1 } },
    [...requiredGuards, "expected_head_revision", "version"]
  ),
  publicationResultV3: obj(
    { version: { type: "integer", minimum: 1 }, head_revision: { type: "integer", minimum: 1 } },
    ["version", "head_revision"]
  ),
  publicationHead: obj({
    current: n,
    latest: n,
    healthy: n,
    head_revision: n,
    needs_republication: bool
  }, ["current", "latest", "healthy", "head_revision"]),
  transferDescriptor: obj({
    transfer_id: s(),
    phase: { enum: ["queued", "uploading", "ready", "committing", "accepted", "rejected"] },
    blob,
    file,
    error: transferError,
    progress: n
  }, ["transfer_id", "phase"]),
  exportSnapshot: obj(
    { id: s(), expires_at: n, created_at: n, sha256: sha256Schema, size: n },
    ["id", "expires_at", "created_at"]
  ),
  importStage: obj(
    { ...guards, sha256: sha256Schema, expected_head_revision: n, expected_files: { type: "object" } },
    [...requiredGuards, "sha256", "expected_head_revision", "expected_files"]
  )
});

// contract/index.mjs
var ROLES = Object.freeze(["owner", "guest", "display"]);
var DEVICE_PURPOSES = Object.freeze(["general", "camera", "controller", "display", "speaker"]);
var string = { type: "string" };
var integer3 = { type: "integer", minimum: 0 };
var object3 = (properties, required = [], additionalProperties = false) => ({ type: "object", properties, required, additionalProperties });
var path = { anyOf: [string, { type: "array", items: { anyOf: [string, { type: "integer" }] } }] };
var jsonObject = { type: "object" };
var boolean = { type: "boolean" };
var nullableString = { type: ["string", "null"] };
var nullableTime = { anyOf: [integer3, { type: "null" }] };
var shortText = { type: "string", minLength: 1, maxLength: 200 };
var sayProperties = { text: string, speak: boolean, in_reply_to: { type: "integer", minimum: 1 }, device: string, speak_on: string };
var error = object3({ code: string, message: string, details: { type: "array", items: object3({ path: string, message: string }, ["path", "message"]) } }, ["code", "message"], true);
var blobReference = object3({
  id: { type: "string", pattern: "^b_[a-z2-7]{20}$" },
  url: string,
  retention: object3({ keep: { type: "boolean" }, expires_at: { anyOf: [integer3, { type: "null" }] }, reason: { enum: ["pinned", "page_default", "agent_asset", "icon"] } }, ["keep", "expires_at"])
}, ["id", "url"]);
var stateOperation = { anyOf: [
  object3({ op: { const: "set" }, path, value: {} }, ["op", "path", "value"]),
  object3({ op: { const: "delete" }, path }, ["op", "path"])
] };
var deviceInfo = object3({
  id: string,
  name: nullableString,
  role: { enum: ROLES },
  purpose: { enum: DEVICE_PURPOSES },
  pending: boolean,
  connected: boolean,
  primary: boolean,
  last_seen: nullableTime,
  ua: nullableString,
  link: nullableString
}, ["id", "name", "role", "purpose", "pending", "connected", "primary", "last_seen", "ua", "link"]);
var focus = object3({ device: string, expires_at: integer3 }, ["device", "expires_at"]);
var timerRepeat = { anyOf: [
  object3({ every_minutes: { type: "integer", minimum: 1, maximum: 525600 } }, ["every_minutes"]),
  object3({ at: { type: "string", pattern: "^(?:[01]\\d|2[0-3]):[0-5]\\d$" }, days: { type: "array", minItems: 1, maxItems: 7, items: { type: "integer", minimum: 0, maximum: 6 } } }, ["at"])
] };
var timerProperties = {
  title: shortText,
  due_at: { type: "integer", minimum: 0, maximum: 864e13 },
  timezone: { type: "string", minLength: 1, maxLength: 100 },
  repeat: timerRepeat,
  missed: { enum: ["fire_once", "skip"] },
  device: string,
  notify: boolean,
  state: { enum: ["scheduled", "cancelled", "completed"] }
};
var timerWriteProperties = { ...timerProperties, repeat: { anyOf: [timerRepeat, { type: "null" }] }, device: nullableString };
var timer = object3({ ...timerProperties, id: string, created_at: integer3, updated_at: integer3 }, ["id", "title", "due_at", "timezone", "missed", "notify", "state", "created_at", "updated_at"]);
var sessionProperties = {
  purpose: { type: "string", maxLength: 4e3 },
  current_task: { type: "string", maxLength: 4e3 },
  ...Object.fromEntries(["completed", "decisions", "open_questions"].map((key) => [key, { type: "array", maxItems: 50, items: { type: "string", maxLength: 2e3 } }])),
  last_handled_seq: integer3,
  source: { type: "string", maxLength: 4e3 }
};
var session = object3(sessionProperties, ["purpose", "current_task", "completed", "decisions", "open_questions", "last_handled_seq"]);
var identifier = { type: "string", minLength: 1, maxLength: 200 };
var scopeId = { type: "string", pattern: "^(?!(?:__proto__|constructor|prototype)$)[A-Za-z0-9_.:-]{1,160}$" };
var generationToken = { type: "string", minLength: 1, maxLength: 160 };
var commandId = { type: "string", pattern: "^[A-Za-z0-9_.:-]{1,200}$" };
var scopeOperation = { type: "string", pattern: "^(?:state|event|capture|blob\\.pin|file\\.write|publication\\.publish|bundle\\.publish|workflow:[a-z][a-z0-9-]{0,63}:(?:[a-zA-Z][a-zA-Z0-9]{0,79}|\\*))$" };
var generationMap = { type: "object", maxProperties: 128, propertyNames: scopeId, additionalProperties: generationToken };
var guards2 = { cid: commandId, scope: scopeId, expected_generations: generationMap };
var scopeDescriptor = object3({
  id: scopeId,
  generation: generationToken,
  paths: { type: "array", items: { type: "array", items: string } },
  operations: { type: "array", items: scopeOperation }
}, ["id", "generation", "paths", "operations"]);
var workflowDescriptor = object3(
  { id: identifier, interface_version: identifier, schema_version: identifier, implementation_version: identifier, operations: jsonObject },
  ["id", "interface_version", "schema_version"]
);
var coreSchemas = {
  ...durabilitySchemas,
  ...streamSchemas,
  ...blobSchemas,
  scopeId,
  scopeOperation,
  scopeBindings: object3({ paths: { type: "array", maxItems: 128, items: path }, operations: { type: "array", maxItems: 128, items: scopeOperation } }, ["paths", "operations"]),
  preconditions: object3(guards2, ["cid", "expected_generations"], true),
  generationMap,
  scopeDescriptor,
  scopeList: object3({ scopes: { type: "array", items: scopeDescriptor } }, ["scopes"]),
  scopeWrite: object3({ ...guards2, paths: { type: "array", items: path }, operations: { type: "array", items: scopeOperation } }, ["cid", "expected_generations", "paths", "operations"]),
  command: object3({ ...guards2, data: {} }, ["cid", "expected_generations", "data"]),
  workflowDescriptor,
  serviceDescriptor: object3({
    contract: { const: 3 },
    core_release: identifier,
    workflows: { type: "array", items: workflowDescriptor },
    limits: jsonObject
  }, ["contract", "core_release", "workflows", "limits"]),
  error,
  errorResponse: object3({ error }, ["error"]),
  create: object3({ name: { type: "string", maxLength: 200 }, owner: { type: "string", maxLength: 254, pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$" }, lifetime: { const: "ad_hoc" }, mode: { enum: ["interactive", "dashboard"] } }, ["owner"]),
  say: object3(sayProperties, ["text"]),
  probeNonce: { type: "string", pattern: "^[a-z2-7]{20}$" },
  deliveryProbe: object3({
    nonce: { type: "string", pattern: "^[a-z2-7]{20}$" },
    seq: { type: "integer", minimum: 1 },
    created_at: integer3,
    ack_at: nullableTime,
    status_url: string,
    ack_url: string
  }, ["nonce", "seq", "created_at", "ack_at", "status_url", "ack_url"]),
  sayMessage: object3({ ...sayProperties, message_id: string, ts: integer3, present: boolean }, ["text"], true),
  stateOperation,
  stateOperations: { type: "array", items: stateOperation },
  stateUpdate: { anyOf: [
    object3({ ...guards2, ops: { type: "array", items: stateOperation } }, ["cid", "expected_generations", "ops"]),
    object3({ ...guards2, state: jsonObject }, ["cid", "expected_generations", "state"])
  ] },
  sendResult: { anyOf: [
    object3({ status: { const: "accepted" }, seq: { type: "integer", minimum: 1 } }, ["status", "seq"]),
    object3({ status: { const: "queued" } }, ["status"]),
    object3({ status: { const: "rejected" }, error: string, message: string }, ["status", "error"])
  ] },
  blobReference,
  captureOptions: object3({ ...guards2, name: string, data: jsonObject, dataPath: { type: "array", items: string }, keep: { type: "boolean" }, wake: { type: "boolean" } }, ["data"]),
  captureResult: { anyOf: [
    object3({ capture_id: string, status: { const: "accepted" }, seq: { type: "integer", minimum: 1 }, blob: blobReference }, ["capture_id", "status", "seq", "blob"]),
    object3({ capture_id: string, status: { const: "queued" } }, ["capture_id", "status"]),
    object3({ capture_id: string, status: { const: "rejected" }, error: string, message: string }, ["capture_id", "status", "error"])
  ] },
  event: object3({ seq: { type: "integer", minimum: 1 }, ts: integer3, type: string, role: { enum: [...ROLES, null] }, device: { anyOf: [string, { type: "null" }] }, by: nullableString, data: {}, wake: { type: "boolean" }, withheld: { type: "boolean" }, context: object3({ scope: identifier, generations: generationMap, workflow: identifier, operation: identifier }, ["generations"]) }, ["seq", "ts", "type", "data"], true),
  device: object3({ id: string, name: string, role: { enum: ROLES }, purpose: { enum: DEVICE_PURPOSES }, pending: { type: "boolean" } }, ["id", "role"], true),
  deviceInfo,
  deviceUpdate: object3({ id: string, name: { anyOf: [{ type: "string", minLength: 1, maxLength: 100 }, { type: "null" }] }, purpose: { enum: DEVICE_PURPOSES } }),
  deviceConfiguration: object3({ devices: { type: "array", items: deviceInfo }, focus: { anyOf: [focus, { type: "null" }] } }, ["devices", "focus"]),
  focus,
  focusRequest: object3({ device: nullableString, ttl_seconds: { type: "integer", minimum: 30, maximum: 86400 } }, ["device"]),
  timerRepeat,
  timer,
  timerWrite: object3(timerWriteProperties),
  timerCreate: object3(timerWriteProperties, ["title"]),
  timerRun: object3({
    id: string,
    timer_id: string,
    scheduled_at: integer3,
    fired_at: integer3,
    status: { enum: ["fired", "skipped"] },
    event_seq: nullableTime,
    delivery: { anyOf: [durabilitySchemas.timerDelivery, { type: "null" }] }
  }, ["id", "timer_id", "scheduled_at", "fired_at", "status", "event_seq", "delivery"]),
  session,
  sessionWrite: object3({ ...sessionProperties, expected_revision: integer3 }),
  sessionSummary: object3({
    session,
    revision: integer3,
    version: integer3,
    staged_remix: boolean,
    pending_inputs: object3({ after: integer3, count: integer3, earliest_available_seq: nullableTime, history_gap: boolean }, ["after", "count", "earliest_available_seq", "history_gap"]),
    timers: { type: "array", items: timer },
    devices: { type: "array", items: deviceInfo },
    recent_activity: { type: "array", items: object3({ ts: integer3, kind: string, summary: string }, ["ts", "kind", "summary"]) }
  }, ["session", "revision", "version", "staged_remix", "pending_inputs", "timers", "devices", "recent_activity"]),
  bundle: object3({
    format: { const: "tendriller-bundle" },
    version: { const: 2 },
    name: { type: "string", minLength: 1, maxLength: 200 },
    files: { type: "array", minItems: 1, maxItems: 2e3, items: object3({ path: string, type: { type: "string", maxLength: 200 }, base64: string }, ["path", "type", "base64"]) },
    state: jsonObject,
    session,
    media: { type: "array", items: object3({ id: blobReference.properties.id, type: { type: "string", maxLength: 200 }, name: { anyOf: [{ type: "string", maxLength: 200 }, { type: "null" }] }, base64: string }, ["id", "type", "name", "base64"]) },
    shared_files: { type: "array", maxItems: 1e3, items: object3({
      path: string,
      blob_id: blobReference.properties.id,
      name: { anyOf: [{ type: "string", maxLength: 200 }, { type: "null" }] },
      type: { anyOf: [{ type: "string", maxLength: 200 }, { type: "null" }] }
    }, ["path", "blob_id", "name", "type"]) }
  }, ["format", "version", "name", "files", "media", "shared_files"]),
  bundlePublish: object3({ ...guards2, expected_version: integer3 }, ["cid", "expected_generations", "expected_version"]),
  remix: object3({ owner: { type: "string", maxLength: 254, pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$" }, name: { type: "string", maxLength: 200 }, include_data: boolean }, ["owner"]),
  remixPage: object3({ name: { type: "string", maxLength: 200 }, include_data: boolean })
};
var list = (items) => ({ type: "array", items });
var pageHandle = object3({
  id: string,
  api: string,
  token: string,
  page_url: string,
  name: string,
  expires_at: { anyOf: [integer3, { type: "null" }] },
  next_step: string
}, ["id", "api", "token", "page_url"], true);
var schemas = Object.freeze({
  ...coreSchemas,
  pageHandle,
  objectResponse: jsonObject,
  sayResult: object3({ ok: { const: true }, message_id: string, in_reply_to: nullableTime }, ["ok", "message_id", "in_reply_to"], true),
  stateSnapshot: object3({ state: jsonObject, rev: integer3, scopes: { type: "array", items: scopeDescriptor } }, ["state", "rev", "scopes"], true),
  stateRevision: object3({ rev: integer3 }, ["rev"], true),
  eventBatch: object3({ events: list(coreSchemas.event), cursor: integer3, withheld: integer3 }, ["events", "cursor", "withheld"], true),
  timerList: object3({ timers: list(timer), execution: { const: "server" }, lifetime: { enum: ["ad_hoc", "resident"] }, expires_at: nullableTime }, ["timers", "execution", "lifetime", "expires_at"], true),
  timerHistory: object3({ runs: list(coreSchemas.timerRun) }, ["runs"], true),
  sessionResult: object3({ session, revision: integer3 }, ["session", "revision"], true),
  bundleStage: object3({ staged: { const: true }, files: integer3, media: integer3, expected_version: integer3, requires_publication: { const: true } }, ["staged", "files", "media", "expected_version", "requires_publication"], true),
  publicationResult: object3({ version: integer3 }, ["version"], true),
  remixResult: object3({ ...pageHandle.properties, remix: object3({ staged: { const: true }, requires_receiver: { const: true }, publish_url: string, expected_version: integer3 }, ["staged", "requires_receiver", "publish_url", "expected_version"], true) }, [...pageHandle.required, "remix"], true)
});
var schemaDocument = Object.freeze({
  $schema: "https://json-schema.org/draft/2020-12/schema",
  $id: "https://tendriller.dev/contract/v3.json",
  title: "Tendriller public contract v3",
  $defs: schemas
});
function validateSchema(schema, value, path2 = "$", depth = 0) {
  if (depth > 128) return [{ path: path2, message: "Maximum validation depth exceeded" }];
  const issues = [];
  const issue = (message) => issues.push({ path: path2, message });
  if (schema.$ref) {
    const name2 = /^#\/\$defs\/([A-Za-z0-9]+)$/.exec(schema.$ref)?.[1];
    if (!name2 || !Object.hasOwn(schemas, name2)) throw new TypeError(`Unknown contract reference: ${schema.$ref}`);
    issues.push(...validateSchema(schemas[name2], value, path2, depth + 1));
  }
  if (schema.anyOf) {
    const alternatives = schema.anyOf.map((s2) => validateSchema(s2, value, path2, depth + 1));
    if (alternatives.every((a) => a.length)) issues.push(...alternatives.sort((a, b) => a.length - b.length)[0]);
  }
  if (Object.hasOwn(schema, "const") && value !== schema.const) issue(`Expected ${JSON.stringify(schema.const)}`);
  if (schema.enum && !schema.enum.includes(value)) issue(`Expected one of ${schema.enum.map((v) => JSON.stringify(v)).join(", ")}`);
  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    const valid = types.some((type) => type === "object" ? value !== null && typeof value === "object" && !Array.isArray(value) : type === "array" ? Array.isArray(value) : type === "null" ? value === null : type === "integer" ? Number.isSafeInteger(value) : type === "number" ? typeof value === "number" && Number.isFinite(value) : typeof value === type);
    if (!valid) {
      issue(`Expected ${types.join(" or ")}`);
      return issues;
    }
  }
  if (typeof value === "string") {
    if (schema.minLength !== void 0 && value.length < schema.minLength) issue(`Minimum length is ${schema.minLength}`);
    if (schema.maxLength !== void 0 && value.length > schema.maxLength) issue(`Maximum length is ${schema.maxLength}`);
    if (schema.pattern && !new RegExp(schema.pattern).test(value)) issue("Value does not match the required format");
    if (schema["x-canonical-nfc"] && value.normalize("NFC") !== value) issue("Value must use canonical Unicode NFC");
  }
  if (typeof value === "number") {
    if (schema.minimum !== void 0 && value < schema.minimum) issue(`Minimum is ${schema.minimum}`);
    if (schema.maximum !== void 0 && value > schema.maximum) issue(`Maximum is ${schema.maximum}`);
  }
  if (Array.isArray(value)) {
    if (schema.minItems !== void 0 && value.length < schema.minItems) issue(`Minimum number of items is ${schema.minItems}`);
    if (schema.maxItems !== void 0 && value.length > schema.maxItems) issue(`Maximum number of items is ${schema.maxItems}`);
    if (schema.items) value.forEach((v, i) => issues.push(...validateSchema(schema.items, v, `${path2}[${i}]`, depth + 1)));
  } else if (value !== null && typeof value === "object") {
    if (schema.maxProperties !== void 0 && Object.keys(value).length > schema.maxProperties) issue(`Maximum number of properties is ${schema.maxProperties}`);
    if (schema.propertyNames) for (const key of Object.keys(value)) issues.push(...validateSchema(schema.propertyNames, key, `${path2}.${key}`, depth + 1));
    for (const key of schema.required || []) if (!Object.hasOwn(value, key)) issues.push({ path: `${path2}.${key}`, message: "Required field" });
    for (const [key, v] of Object.entries(value)) {
      if (["__proto__", "constructor", "prototype"].includes(key)) {
        issues.push({ path: `${path2}.${key}`, message: "Reserved key" });
        continue;
      }
      const child = schema.properties?.[key];
      if (child) issues.push(...validateSchema(child, v, `${path2}.${key}`, depth + 1));
      else if (schema.additionalProperties === false) issues.push({ path: `${path2}.${key}`, message: "Unknown field" });
      else if (typeof schema.additionalProperties === "object") issues.push(...validateSchema(schema.additionalProperties, v, `${path2}.${key}`, depth + 1));
    }
  }
  return issues;
}
function validate(name2, value) {
  if (!Object.hasOwn(schemas, name2)) throw new TypeError(`Unknown contract schema: ${name2}`);
  return validateSchema(schemas[name2], value);
}

// server/src/http.ts
var HttpError = class extends Error {
  constructor(status, code, message, extra) {
    super(message ?? code);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
  status;
  code;
  extra;
};
function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// server/src/state.ts
var FORBIDDEN = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
function normPath(p) {
  const arr2 = typeof p === "string" ? p.split(".").filter((s2) => s2 !== "") : p;
  if (!Array.isArray(arr2)) throw new HttpError(400, "bad_ops", "Op path must be an array of keys");
  return arr2.map((k) => {
    if (typeof k === "number") return String(k);
    if (typeof k !== "string") throw new HttpError(400, "bad_ops", "Op path keys must be strings");
    if (FORBIDDEN.has(k)) throw new HttpError(400, "bad_ops", `Key "${k}" is not allowed`);
    return k;
  });
}
function validateValue(value, depth = 0) {
  if (depth > 128) throw new HttpError(400, "bad_ops", "State nesting exceeds 128 levels");
  if (Array.isArray(value)) {
    for (const item of value) validateValue(item, depth + 1);
    return;
  }
  if (isPlainObject(value)) for (const [key, child] of Object.entries(value)) {
    if (FORBIDDEN.has(key)) throw new HttpError(400, "bad_ops", `Key "${key}" is not allowed`);
    validateValue(child, depth + 1);
  }
}
function validateOps(raw) {
  const issues = validate("stateOperations", raw);
  if (issues.length) throw new HttpError(400, "bad_ops", issues.map((i) => `${i.path}: ${i.message}`).join("; "), { details: issues });
  if (!Array.isArray(raw)) throw new HttpError(400, "bad_ops", "ops must be an array");
  return raw.map((o) => {
    if (!isPlainObject(o)) throw new HttpError(400, "bad_ops", "Each op must be an object");
    const path2 = normPath(o.path);
    if (o.op === "set") {
      validateValue(o.value);
      if (path2.length === 0 && !isPlainObject(o.value)) throw new HttpError(400, "bad_ops", "The root state must be an object");
      return { op: "set", path: path2, value: o.value === void 0 ? null : o.value };
    }
    if (o.op === "delete") {
      if (path2.length === 0) throw new HttpError(400, "bad_ops", "Cannot delete the root");
      return { op: "delete", path: path2 };
    }
    throw new HttpError(400, "bad_ops", `Unknown op "${String(o.op)}"`);
  });
}
function applyOps(state, ops) {
  for (const op of ops) {
    if (op.path.length === 0) {
      if (op.op === "set") {
        for (const k of Object.keys(state)) delete state[k];
        Object.assign(state, structuredClone(op.value));
      }
      continue;
    }
    let node = state;
    const last = op.path[op.path.length - 1];
    let ok = true;
    for (const key of op.path.slice(0, -1)) {
      if (!isPlainObject(node[key])) {
        if (op.op === "delete") {
          ok = false;
          break;
        }
        node[key] = {};
      }
      node = node[key];
    }
    if (!ok) continue;
    if (op.op === "set") node[last] = op.value;
    else delete node[last];
  }
  return state;
}

// server/src/streams/history.ts
function mergeHistoryGaps(first, second) {
  return {
    from: first.from === null ? second.from : second.from === null ? first.from : Math.min(first.from, second.from),
    through: first.through === null ? second.through : second.through === null ? first.through : Math.max(first.through, second.through)
  };
}
function historyGap(records, after, boundary) {
  let next = after + 1, gap = { from: null, through: null };
  for (const record2 of records) {
    if (record2.seq > next) gap = mergeHistoryGaps(gap, { from: next, through: record2.seq - 1 });
    next = record2.seq + 1;
  }
  if (boundary >= next) gap = mergeHistoryGaps(gap, { from: next, through: boundary });
  return gap;
}
function historyPage(rows, options) {
  const records = [];
  let used = 0, truncated = false;
  for (const record2 of rows) {
    const size = options.sizeOf?.(record2) ?? 0;
    if (records.length && used + size > (options.maxBytes ?? Infinity)) {
      truncated = true;
      break;
    }
    records.push(record2);
    used += size;
  }
  const cursor = records.at(-1)?.seq ?? options.after;
  const exhausted = !truncated && records.length < options.limit;
  const gap = historyGap(records, options.after, exhausted ? options.latest : cursor);
  return { records, cursor, gap, history: {
    earliest_available_seq: options.earliest,
    latest_seq: options.latest,
    gap: gap.from !== null,
    missing_through: gap.through
  } };
}

// runtime/src/state.ts
function toPath(p) {
  if (p == null || p === "") return [];
  if (Array.isArray(p)) return p.map(String);
  return String(p).split(".");
}

// contract/scopes.mjs
function pathsOverlap(left, right) {
  return left.slice(0, Math.min(left.length, right.length)).every((part, index) => part === right[index]);
}
function operationMatches(binding, operation) {
  return binding.endsWith(":*") ? operation.startsWith(binding.slice(0, -1)) : binding === operation;
}
function selectScopes(descriptors, { paths = [], operations = [], scopes = [] } = {}) {
  const explicit = new Set(scopes);
  return descriptors.filter((binding) => explicit.has(binding.id) || binding.paths.some((bound) => paths.some((path2) => pathsOverlap(bound, path2))) || binding.operations.some((bound) => operations.some((operation) => operationMatches(bound, operation))));
}

// runtime/src/generations.ts
function requiredScopes(scopes, operation, paths = [], scope2) {
  return selectScopes(scopes, { operations: [operation], paths, scopes: scope2 ? [scope2] : [] });
}
function captureContext(scopes, operation, options = {}, ops = []) {
  const required = requiredScopes(scopes, operation, ops.map((op) => toPath(op.path)), options.scope);
  if (options.scope && !scopes.some((binding) => binding.id === options.scope)) {
    throw Object.assign(new Error(`Scope ${options.scope} is not active on this page.`), { code: "unknown_scope" });
  }
  const expected2 = options.expected_generations !== void 0 ? { ...options.expected_generations } : Object.fromEntries(required.map((binding) => [binding.id, binding.generation]));
  return { ...options.scope ? { scope: options.scope } : {}, expected_generations: expected2 };
}
function matchesContext(scopes, context, operation, ops = []) {
  const actual = new Map(scopes.map((binding) => [binding.id, binding.generation]));
  for (const [id, generation] of Object.entries(context.expected_generations)) {
    if (actual.get(id) !== generation) return false;
  }
  for (const binding of requiredScopes(scopes, operation, ops.map((op) => toPath(op.path)), context.scope)) {
    if (context.expected_generations[binding.id] !== binding.generation) return false;
  }
  return !context.scope || actual.has(context.scope);
}
export {
  applyOps,
  captureContext,
  historyGap,
  historyPage,
  matchesContext,
  mergeHistoryGaps,
  requiredScopes,
  validateOps
};
